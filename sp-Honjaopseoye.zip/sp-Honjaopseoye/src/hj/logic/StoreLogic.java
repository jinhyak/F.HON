package hj.logic;

public class StoreLogic {

}
