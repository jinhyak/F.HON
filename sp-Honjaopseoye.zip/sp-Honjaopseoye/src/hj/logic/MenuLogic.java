package hj.logic;

public class MenuLogic {

}
