package hj.logic;

public class FriendLogic {

}
