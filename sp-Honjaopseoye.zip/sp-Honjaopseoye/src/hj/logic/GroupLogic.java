package hj.logic;

public class GroupLogic {

}
