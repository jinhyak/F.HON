package hj.dao;

public class StoreDao {

}
