package hj.dao;

public class GroupDao {

}
