package hj.dao;

import java.util.List;
import java.util.Map;

public class ReplyDao{

	public List<Map<String, Object>> select(Map<String, Object> pMap) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insert(Map<String, Object> pMap) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int update(Map<String, Object> pMap) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int delete(Map<String, Object> pMap) {
		// TODO Auto-generated method stub
		return 0;
	}

}
